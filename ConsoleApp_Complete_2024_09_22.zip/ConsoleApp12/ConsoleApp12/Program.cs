﻿using System;

class Program
{
    static void Main(string[] args)
    { 
        int x = Console.WindowWidth / 2;
        int y = Console.WindowHeight / 2;
        ConsoleKeyInfo gombInfo;
        ConsoleColor[] szinek = new ConsoleColor[]
        {
            ConsoleColor.Red,
            ConsoleColor.Green,
            ConsoleColor.Blue,
            ConsoleColor.Yellow,
            ConsoleColor.Cyan,
            ConsoleColor.Magenta,
            ConsoleColor.White
        };
        int jelenlegiSzín = 0;

        string currentChar = "█";

        while (true)
        {
           
            // A karakter színváltozása
            Console.ForegroundColor = szinek[jelenlegiSzín];

            // Egy "█" rajzolása a porzícióban
            Console.SetCursorPosition(x, y);
            

            // Gomb lenyomás 
            gombInfo = Console.ReadKey(true);

            // Mozgás és karakterváltás
            switch (gombInfo.Key)
            {
                case ConsoleKey.UpArrow:
                    if (y > 0) y--;
                    break;
                case ConsoleKey.DownArrow:
                    if (y < Console.WindowHeight - 1) y++;
                    break;
                case ConsoleKey.LeftArrow:
                    if (x > 0) x--;
                    break;
                case ConsoleKey.RightArrow:
                    if (x < Console.WindowWidth - 1) x++;
                    break;
                case ConsoleKey.D:
                    currentChar = "█";
                    break;
                case ConsoleKey.D8:
                    currentChar = "▓";
                    break;
                case ConsoleKey.D9:
                    currentChar = "▒";
                    break;
                case ConsoleKey.D0:
                    currentChar = "░";
                    break;
                case ConsoleKey.Spacebar:
                    Console.Write(currentChar);
                    break;
                
                case ConsoleKey.Escape:
                    return;
            }
            // Szinek asszociálása a számokhoz
            if (gombInfo.Key >= ConsoleKey.D1 && gombInfo.Key <= ConsoleKey.D7)
            {
                int választottSzám = gombInfo.Key - ConsoleKey.D1 + 1;

                for (int i = 1; i <= választottSzám; i++)
                {
                    jelenlegiSzín = (i - 1) % szinek.Length;
                }
            }
        }
    }
}
