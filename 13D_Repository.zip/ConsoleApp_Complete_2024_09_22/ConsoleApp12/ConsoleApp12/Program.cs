﻿using System;
using System.Reflection.Metadata.Ecma335;

class Program
{
    static void DrawEdges()
    {
        Console.SetCursorPosition(0, 0);
        Console.Write("╔");
        Console.SetCursorPosition(Console.WindowWidth - 1, 0);
        Console.Write("╗");
        Console.SetCursorPosition(Console.WindowWidth - 1, Console.WindowHeight - 1);
        Console.Write("╝");
        Console.SetCursorPosition(0, Console.WindowHeight - 1);
        Console.Write("╚");

        int keretX = Console.WindowWidth - 2;
        int keretY = Console.WindowHeight - 2;
        Console.SetCursorPosition(keretX, keretY);

        for (int i = 0; i < Console.WindowWidth - 2; i++)
        {
            Console.SetCursorPosition(i + 1, 0);
            Console.Write("═");

        }
        for (int i = 0; i < Console.WindowWidth - 2; i++)
        {
            Console.SetCursorPosition(i + 1, Console.WindowHeight - 1);
            Console.Write("═");

        }

        for (int j = 1; j < Console.WindowHeight - 1; j++)
        {
            Console.SetCursorPosition(Console.WindowWidth - 1, j);
            Console.Write("║");

        }

        for (int j = 1; j < Console.WindowHeight - 1; j++)
        {
            Console.SetCursorPosition(0, j);
            Console.Write("║");

        }
    }
    static void Main(string[] args)
    { 
        int x = Console.WindowWidth / 2;
        int y = Console.WindowHeight / 2;
        ConsoleKeyInfo gombInfo;
        ConsoleColor[] szinek = new ConsoleColor[]
        {
            ConsoleColor.Red,
            ConsoleColor.Green,
            ConsoleColor.Blue,
            ConsoleColor.Yellow,
            ConsoleColor.Cyan,
            ConsoleColor.Magenta,
            ConsoleColor.White
        };
        int jelenlegiSzín = 0;

        string jelenlegiKarakter = "█";
       

        DrawEdges();

        static void DrawButton1(pozX, pozY)
        {
            int pozX = 0;
            int pozY = 0;
            Console.SetCursorPosition(49, Console.WindowHeight / 2);
            Console.Write("┌");
            Console.SetCursorPosition(71, Console.WindowHeight / 2);
            Console.Write("┐");
            Console.SetCursorPosition(71, Console.WindowHeight / 2 + 2);
            Console.Write("┘");
            Console.SetCursorPosition(49, Console.WindowHeight / 2 + 2);
            Console.Write("└");
            Console.SetCursorPosition(49, Console.WindowHeight / 2 + 1);
            Console.Write("│");
            Console.SetCursorPosition(71, Console.WindowHeight / 2 + 1);
            Console.Write("│");

            for (int i = 50; i < Console.WindowWidth - 49; i++)
            {
                Console.SetCursorPosition(i, Console.WindowHeight / 2);
                Console.Write("─");
            }
            for (int i = 50; i < Console.WindowWidth - 49; i++)
            {
                Console.SetCursorPosition(i, Console.WindowHeight / 2 + 2);
                Console.Write("─");
            }

        }
        DrawButton1();


        while (true)
        {
       
            // A karakter színváltozása
            Console.ForegroundColor = szinek[jelenlegiSzín];

            // Egy "█" rajzolása a porzícióban
            Console.SetCursorPosition(x, y);
            

            // Gomb lenyomás 
            gombInfo = Console.ReadKey(true);

            // Mozgás és karakterváltás
            switch (gombInfo.Key)
            {
                case ConsoleKey.UpArrow:
                    if (y > 0) y--;
                    break;
                case ConsoleKey.DownArrow:
                    if (y < Console.WindowHeight - 1) y++;
                    break;
                case ConsoleKey.LeftArrow:
                    if (x > 0) x--;
                    break;
                case ConsoleKey.RightArrow:
                    if (x < Console.WindowWidth - 1) x++;
                    break;
                case ConsoleKey.D:
                    jelenlegiKarakter = "█";
                    break;
                case ConsoleKey.D8:
                    jelenlegiKarakter = "▓";
                    break;
                case ConsoleKey.D9:
                    jelenlegiKarakter = "▒";
                    break;
                case ConsoleKey.D0:
                    jelenlegiKarakter = "░";
                    break;
                case ConsoleKey.Spacebar:
                    Console.Write(jelenlegiKarakter);
                    break;
                
                case ConsoleKey.Escape:
                    return;
            }
            // Szinek asszociálása a számokhoz
            if (gombInfo.Key >= ConsoleKey.D1 && gombInfo.Key <= ConsoleKey.D7)
            {
                int választottSzám = gombInfo.Key - ConsoleKey.D1 + 1;

                for (int i = 1; i <= választottSzám; i++)
                {
                    jelenlegiSzín = (i - 1) % szinek.Length;
                }
            }
        }
    }
}
